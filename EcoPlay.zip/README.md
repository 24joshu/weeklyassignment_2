# EcoPlay — Gamified Environmental Education Platform

A minimal, ready-to-run scaffold (Flask + SQLite backend, lightweight HTML/JS frontend).  
Built on 2025-08-31 07:58:48.

## Features (MVP)
- JWT auth (register/login)
- Quizzes: CRUD (teacher), take quiz (student), award eco-points
- Challenges: CRUD + submissions with media proof URL
- Badges: auto-awarded based on points thresholds
- Leaderboard: per-school, overall
- Simple frontend (no build step) that talks to API

## Quick Start

### Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate
pip install -r requirements.txt

# Initialize DB with seed data
python app.py --initdb

# Run
python app.py
# API base: http://127.0.0.1:5000/api
```

### Frontend
Just open `frontend/index.html` in a browser (or serve via any static server).  
Set `API_BASE` in `frontend/js/config.js` if your backend runs on a different host/port.

## Default roles
- `student`, `teacher`, `admin`

## Env
Create `backend/.env` (optional):
```
SECRET_KEY=change-me
JWT_EXPIRE_MIN=1440
```

## Folder Structure
See `docs/architecture.md` and `docs/api_endpoints.md`.
