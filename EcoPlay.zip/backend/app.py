import os, json, argparse, datetime, functools
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from passlib.hash import pbkdf2_sha256
import jwt
from dotenv import load_dotenv

load_dotenv()

SECRET = os.getenv("SECRET_KEY", "dev-secret-change-me")
JWT_EXPIRE_MIN = int(os.getenv("JWT_EXPIRE_MIN", "1440"))

app = Flask(__name__)
CORS(app)

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///ecoplay.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

# ----------------- Models -----------------
class School(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    city = db.Column(db.String(120))
    state = db.Column(db.String(120))

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="student") # student|teacher|admin
    school_id = db.Column(db.Integer, db.ForeignKey('school.id'))
    school = db.relationship('School')
    eco_points = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

class Quiz(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, default="")
    difficulty = db.Column(db.String(20), default="easy")
    eco_points = db.Column(db.Integer, default=10)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'))

class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    text = db.Column(db.Text, nullable=False)
    options = db.Column(db.Text, nullable=False)  # JSON list
    answer_index = db.Column(db.Integer, nullable=False)

class QuizAttempt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    score = db.Column(db.Integer, default=0) # correct answers count
    points_awarded = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

class Challenge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, default="")
    eco_points = db.Column(db.Integer, default=20)
    created_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    status = db.Column(db.String(20), default="active")

class Submission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    challenge_id = db.Column(db.Integer, db.ForeignKey('challenge.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    proof_url = db.Column(db.String(500), default="")
    notes = db.Column(db.Text, default="")
    status = db.Column(db.String(20), default="pending") # pending|approved|rejected
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

class Badge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, default="")
    threshold_points = db.Column(db.Integer, default=100)

class UserBadge(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    badge_id = db.Column(db.Integer, db.ForeignKey('badge.id'), nullable=False)
    awarded_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

# ----------------- Utils -----------------
def create_token(user):
    payload = {
        "uid": user.id,
        "role": user.role,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=JWT_EXPIRE_MIN)
    }
    return jwt.encode(payload, SECRET, algorithm="HS256")

def auth_required(roles=None):
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            auth = request.headers.get("Authorization", "")
            if not auth.startswith("Bearer "):
                return jsonify({"error": "Missing token"}), 401
            token = auth.split(" ", 1)[1]
            try:
                payload = jwt.decode(token, SECRET, algorithms=["HS256"])
            except Exception as e:
                return jsonify({"error": "Invalid token"}), 401
            request.user = User.query.get(payload["uid"])
            if roles and request.user.role not in roles:
                return jsonify({"error": "Forbidden"}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator

def award_points(user: User, points: int):
    user.eco_points += points
    db.session.commit()
    # check badges
    badges = Badge.query.order_by(Badge.threshold_points.asc()).all()
    owned = {ub.badge_id for ub in UserBadge.query.filter_by(user_id=user.id).all()}
    for b in badges:
        if user.eco_points >= b.threshold_points and b.id not in owned:
            db.session.add(UserBadge(user_id=user.id, badge_id=b.id))
    db.session.commit()

# ----------------- Routes -----------------
@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.post("/api/auth/register")
def register():
    data = request.get_json() or {}
    name = data.get("name")
    email = data.get("email")
    pwd = data.get("password")
    role = data.get("role", "student")
    school_id = data.get("school_id")
    if not all([name, email, pwd]):
        return {"error": "name, email, password required"}, 400
    if User.query.filter_by(email=email).first():
        return {"error": "email exists"}, 400
    u = User(name=name, email=email, password_hash=pbkdf2_sha256.hash(pwd), role=role, school_id=school_id)
    db.session.add(u)
    db.session.commit()
    return {"message": "registered"}

@app.post("/api/auth/login")
def login():
    data = request.get_json() or {}
    email = data.get("email"); pwd = data.get("password")
    u = User.query.filter_by(email=email).first()
    if not u or not pbkdf2_sha256.verify(pwd, u.password_hash):
        return {"error": "invalid credentials"}, 401
    return {"token": create_token(u), "user": {"id": u.id, "name": u.name, "role": u.role, "eco_points": u.eco_points, "school_id": u.school_id}}

@app.get("/api/me")
@auth_required()
def me():
    u = request.user
    badges = [{"id": ub.badge_id} for ub in UserBadge.query.filter_by(user_id=u.id).all()]
    return {"id": u.id, "name": u.name, "role": u.role, "eco_points": u.eco_points, "school_id": u.school_id, "badges": badges}

# ---- Quizzes ----
@app.get("/api/quizzes")
@auth_required()
def list_quizzes():
    quizzes = Quiz.query.all()
    out = []
    for q in quizzes:
        out.append({"id": q.id, "title": q.title, "description": q.description, "difficulty": q.difficulty, "eco_points": q.eco_points})
    return {"items": out}

@app.post("/api/quizzes")
@auth_required(roles=["teacher","admin"])
def create_quiz():
    data = request.get_json() or {}
    q = Quiz(title=data.get("title"), description=data.get("description",""), difficulty=data.get("difficulty","easy"), eco_points=int(data.get("eco_points",10)), created_by=request.user.id)
    db.session.add(q); db.session.commit()
    for item in data.get("questions", []):
        db.session.add(Question(quiz_id=q.id, text=item["text"], options=json.dumps(item["options"]), answer_index=int(item["answer_index"])))
    db.session.commit()
    return {"id": q.id}

@app.get("/api/quizzes/<int:qid>")
@auth_required()
def get_quiz(qid):
    q = Quiz.query.get_or_404(qid)
    questions = Question.query.filter_by(quiz_id=q.id).all()
    return {"id": q.id, "title": q.title, "description": q.description, "difficulty": q.difficulty, "eco_points": q.eco_points,
            "questions": [{"id": x.id, "text": x.text, "options": json.loads(x.options)} for x in questions]}

@app.put("/api/quizzes/<int:qid>")
@auth_required(roles=["teacher","admin"])
def update_quiz(qid):
    q = Quiz.query.get_or_404(qid)
    data = request.get_json() or {}
    q.title = data.get("title", q.title)
    q.description = data.get("description", q.description)
    q.difficulty = data.get("difficulty", q.difficulty)
    q.eco_points = int(data.get("eco_points", q.eco_points))
    db.session.commit()
    return {"message": "updated"}

@app.delete("/api/quizzes/<int:qid>")
@auth_required(roles=["teacher","admin"])
def delete_quiz(qid):
    q = Quiz.query.get_or_404(qid)
    Question.query.filter_by(quiz_id=q.id).delete()
    db.session.delete(q); db.session.commit()
    return {"message": "deleted"}

@app.post("/api/quizzes/<int:qid>/attempt")
@auth_required()
def attempt_quiz(qid):
    u = request.user
    q = Quiz.query.get_or_404(qid)
    data = request.get_json() or {}
    answers = data.get("answers", {})  # {question_id: chosen_index}
    questions = Question.query.filter_by(quiz_id=q.id).all()
    correct = 0
    for qs in questions:
        if str(qs.id) in answers and int(answers[str(qs.id)]) == qs.answer_index:
            correct += 1
    points = int(round((correct / max(1,len(questions))) * q.eco_points))
    db.session.add(QuizAttempt(user_id=u.id, quiz_id=q.id, score=correct, points_awarded=points))
    db.session.commit()
    award_points(u, points)
    return {"correct": correct, "total": len(questions), "points_awarded": points}

# ---- Challenges & Submissions ----
@app.get("/api/challenges")
@auth_required()
def list_challenges():
    items = []
    for c in Challenge.query.filter_by(status="active").all():
        items.append({"id": c.id, "title": c.title, "description": c.description, "eco_points": c.eco_points})
    return {"items": items}

@app.post("/api/challenges")
@auth_required(roles=["teacher","admin"])
def create_challenge():
    data = request.get_json() or {}
    c = Challenge(title=data.get("title"), description=data.get("description",""), eco_points=int(data.get("eco_points",20)), created_by=request.user.id)
    db.session.add(c); db.session.commit()
    return {"id": c.id}

@app.post("/api/challenges/<int:cid>/submit")
@auth_required()
def submit_challenge(cid):
    u = request.user
    c = Challenge.query.get_or_404(cid)
    data = request.get_json() or {}
    s = Submission(challenge_id=c.id, user_id=u.id, proof_url=data.get("proof_url",""), notes=data.get("notes",""))
    db.session.add(s); db.session.commit()
    return {"submission_id": s.id, "status": s.status}

@app.put("/api/submissions/<int:sid>/verify")
@auth_required(roles=["teacher","admin"])
def verify_submission(sid):
    data = request.get_json() or {}
    s = Submission.query.get_or_404(sid)
    status = data.get("status")
    if status not in ("approved","rejected"):
        return {"error":"status must be approved|rejected"}, 400
    s.status = status
    db.session.commit()
    if status == "approved":
        u = User.query.get(s.user_id)
        c = Challenge.query.get(s.challenge_id)
        award_points(u, c.eco_points)
    return {"message": "updated"}

# ---- Badges & Leaderboard ----
@app.get("/api/badges")
@auth_required()
def list_badges():
    items = []
    for b in Badge.query.order_by(Badge.threshold_points.asc()).all():
        items.append({"id": b.id, "name": b.name, "threshold_points": b.threshold_points})
    return {"items": items}

@app.get("/api/leaderboard")
@auth_required()
def leaderboard():
    scope = request.args.get("scope","global")
    school_id = request.args.get("school_id")
    q = User.query
    if scope == "school" and school_id:
        q = q.filter_by(school_id=int(school_id))
    users = q.order_by(User.eco_points.desc()).limit(50).all()
    return {"items": [{"id": u.id, "name": u.name, "eco_points": u.eco_points, "school_id": u.school_id} for u in users]}

# ---- DB Init ----
def initdb():
    db.drop_all(); db.create_all()
    s1 = School(name="Govt Sr Sec School A", city="Ludhiana", state="Punjab")
    s2 = School(name="Punjab Engineering College", city="Chandigarh", state="Punjab")
    db.session.add_all([s1,s2]); db.session.commit()

    admin = User(name="Admin", email="admin@ecoplay.in", password_hash=pbkdf2_sha256.hash("admin123"), role="admin", school_id=s1.id)
    teacher = User(name="Teacher", email="teacher@ecoplay.in", password_hash=pbkdf2_sha256.hash("teacher123"), role="teacher", school_id=s1.id)
    student = User(name="Student", email="student@ecoplay.in", password_hash=pbkdf2_sha256.hash("student123"), role="student", school_id=s1.id)
    db.session.add_all([admin, teacher, student]); db.session.commit()

    # Badges
    db.session.add_all([
        Badge(name="Eco Starter", description="100 points", threshold_points=100),
        Badge(name="Green Champion", description="250 points", threshold_points=250),
        Badge(name="Planet Protector", description="500 points", threshold_points=500),
    ]); db.session.commit()

    # Sample Quiz
    q = Quiz(title="Waste Segregation Basics", description="Dry vs Wet vs Hazardous", difficulty="easy", eco_points=20, created_by=teacher.id)
    db.session.add(q); db.session.commit()
    db.session.add_all([
        Question(quiz_id=q.id, text="Which bin for vegetable peels?", options=json.dumps(["Dry","Wet","Hazardous","E-Waste"]), answer_index=1),
        Question(quiz_id=q.id, text="Used battery goes to?", options=json.dumps(["Wet","Hazardous","Dry","Compost"]), answer_index=1),
        Question(quiz_id=q.id, text="Newspaper is?", options=json.dumps(["Dry","Wet","Hazardous","Medical"]), answer_index=0),
    ]); db.session.commit()

    # Sample Challenge
    c = Challenge(title="Plant a native tree", description="Plant & care for a native species; upload a photo", eco_points=30, created_by=teacher.id)
    db.session.add(c); db.session.commit()
    print("Database initialized with seed data.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--initdb", action="store_true")
    args = parser.parse_args()
    if args.initdb:
        with app.app_context():
            initdb()
    else:
        app.run(debug=True)
