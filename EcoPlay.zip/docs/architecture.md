# Architecture

- Client (HTML/JS) calls REST API (Flask)
- SQLite via SQLAlchemy ORM
- JWT for stateless auth
- Services layer encapsulates gamification rules
- CORS enabled for local dev

```text
[Frontend] --> [Flask API] --> [Services] --> [SQLAlchemy] --> [SQLite DB]
                         \-> [JWT] (Auth)
```
