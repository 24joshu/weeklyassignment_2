# DB Schema (simplified)

Users(id, name, email, password_hash, role, school_id, eco_points, created_at)
Schools(id, name, city, state)
Quizzes(id, title, description, difficulty, eco_points, created_by)
Questions(id, quiz_id, text, options(json), answer_index)
QuizAttempts(id, user_id, quiz_id, score, points_awarded, created_at)

Challenges(id, title, description, eco_points, created_by, status)
Submissions(id, challenge_id, user_id, proof_url, notes, status, created_at)

Badges(id, name, description, threshold_points)
UserBadges(id, user_id, badge_id, awarded_at)
