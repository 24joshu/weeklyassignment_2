# API Endpoints (MVP)

Auth
- POST /api/auth/register
- POST /api/auth/login

Users
- GET /api/me

Quizzes
- GET /api/quizzes
- POST /api/quizzes               (teacher/admin)
- GET /api/quizzes/<id>
- PUT /api/quizzes/<id>           (teacher/admin)
- DELETE /api/quizzes/<id>        (teacher/admin)
- POST /api/quizzes/<id>/attempt  (student; records score + points)

Challenges
- GET /api/challenges
- POST /api/challenges            (teacher/admin)
- POST /api/challenges/<id>/submit  (student)
- PUT /api/submissions/<id>/verify   (teacher/admin)

Badges
- GET /api/badges

Leaderboard
- GET /api/leaderboard?scope=global|school&school_id=<id>
