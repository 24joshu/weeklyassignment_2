let token = null;

const status = (t)=> document.getElementById('status').textContent = t;
const headers = ()=> token ? { 'Authorization': 'Bearer ' + token, 'Content-Type':'application/json' } : { 'Content-Type':'application/json' };

document.getElementById('loginBtn').onclick = async () => {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const r = await fetch(API_BASE + '/auth/login', {method:'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({email, password})});
  const j = await r.json();
  if (j.token) {
    token = j.token;
    status('Logged in as ' + j.user.name + ' (' + j.user.role + ')');
    const me = await fetch(API_BASE + '/me', {headers: headers()}).then(r=>r.json());
    document.getElementById('me').textContent = JSON.stringify(me, null, 2);
  } else {
    status('Login failed: ' + (j.error || 'unknown'));
  }
};

document.getElementById('loadQuizzes').onclick = async () => {
  const j = await fetch(API_BASE + '/quizzes', {headers: headers()}).then(r=>r.json());
  const div = document.getElementById('quizzes'); div.innerHTML = '';
  j.items.forEach(q => {
    const el = document.createElement('div');
    el.innerHTML = `<details><summary>${q.title} — ${q.eco_points} pts</summary>
      <button data-id="${q.id}" class="take">Take Quiz (auto attempt with correct=all)</button>
    </details>`;
    div.appendChild(el);
  });
  div.querySelectorAll('.take').forEach(btn => {
    btn.onclick = async () => {
      // get quiz, then attempt with all correct (demo)
      const q = await fetch(API_BASE + '/quizzes/' + btn.dataset.id, {headers: headers()}).then(r=>r.json());
      const answers = {};
      q.questions.forEach((qs, idx) => { answers[qs.id] = 0; }); // naive
      // Actually mark all as first option for demo
      const res = await fetch(API_BASE + `/quizzes/${q.id}/attempt`, {method:'POST', headers: headers(), body: JSON.stringify({answers})}).then(r=>r.json());
      alert(`Scored ${res.correct}/${q.questions.length}. Points +${res.points_awarded}`);
    };
  });
};

document.getElementById('loadChallenges').onclick = async () => {
  const j = await fetch(API_BASE + '/challenges', {headers: headers()}).then(r=>r.json());
  const div = document.getElementById('challenges'); div.innerHTML = '';
  j.items.forEach(c => {
    const el = document.createElement('div');
    el.innerHTML = `<details><summary>${c.title} — ${c.eco_points} pts</summary>
      <input placeholder="Proof URL (image/video)" class="proof"/>
      <button data-id="${c.id}" class="submit">Submit</button>
    </details>`;
    div.appendChild(el);
  });
  div.querySelectorAll('.submit').forEach(btn => {
    btn.onclick = async (ev) => {
      const proof = btn.parentElement.querySelector('.proof').value;
      const res = await fetch(API_BASE + `/challenges/${btn.dataset.id}/submit`, {method:'POST', headers: headers(), body: JSON.stringify({proof_url: proof, notes: ''})}).then(r=>r.json());
      alert('Submitted! ID ' + res.submission_id + ', pending teacher approval.');
    };
  });
};

document.getElementById('loadLeaderboard').onclick = async () => {
  const j = await fetch(API_BASE + '/leaderboard', {headers: headers()}).then(r=>r.json());
  const div = document.getElementById('lb'); div.innerHTML = '<ol></ol>';
  const ol = div.querySelector('ol');
  j.items.forEach(u => {
    const li = document.createElement('li');
    li.textContent = `${u.name} — ${u.eco_points} pts`;
    ol.appendChild(li);
  });
};
